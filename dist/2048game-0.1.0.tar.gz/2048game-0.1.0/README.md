### It's 2048 game but it's inside your terminal written in Python

![Screenshot](screenshot.png)

* Terminal size should be at least 90 x 35

* Use arrow keys (right, left, up, down) to move in game
